#include <unistd.h>

//
// A program that launches/executes a shell program (/bin/sh) using execve()
//

int main() {
   char *name[2];
	
   name[0] = "/bin/sh";
   name[1] = NULL;
	
   execve(name[0], name, NULL);
}
