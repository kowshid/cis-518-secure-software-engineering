#include <stdio.h>

void func(int a, int b) {
   int c = 3;
   int d = 4;
   char buf[] = "56789";
	
   printf("%d %d %d %d %s\n\n", a, b, c, d, buf);
	
   printf("Address of b = %p\n", &b);
   printf("Address of a = %p\n", &a);
   printf("Address of c = %p\n", &c);
   printf("Address of d = %p\n", &d);
   printf("Address of buf = %p\n", buf);
}

int main() {
   func(1,2);
   return 0;
}
