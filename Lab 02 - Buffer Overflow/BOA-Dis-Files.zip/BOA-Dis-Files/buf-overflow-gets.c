#include <stdio.h>

int main() {
   int c = 3;
   int d = 4;
   char buf[6];
	
   printf("Enter some text: ");
   gets(buf);
   printf("%d %d %s\n", c, d, buf);
	
   return 0;
}

