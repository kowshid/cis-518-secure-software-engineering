#include <string.h>
#include <stdio.h>

void foo(char *str) {
   char buffer[12];
   strcpy(buffer,str);
   printf("Returning to caller\n");
}

int main() {
   char *str = "This is definitely longer than 12";
   foo(str);
   printf("I am back from foo");
   return 1;
}

