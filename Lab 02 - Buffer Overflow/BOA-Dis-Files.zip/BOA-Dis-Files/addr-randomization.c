// Program to experiment with address randomization settings on Linux
// sysctl kernel.randomize_va_space
// sudo sysctl kernel.randomize_va_space=0	--> no randomization
// sudo sysctl kernel.randomize_va_space=1	--> conservative randomization
// sudo sysctl kernel.randomize_va_space=2  --> full randomization (default)

#include <stdio.h>
#include <stdlib.h>

int main() 
{ 
   char x[12];    // allocated on stack

   char *y;       // allocated on stack

   y = malloc(sizeof(char) * 12);   // y points to allocated memory on heap
	
   printf("Address of array x (on stack): 0x%p\n", x); 
   printf("Address of pointer variable y (on stack): 0x%p\n", &y);
   printf("Address of dynamically allocated storage (on heap): 0x%p\n", y);

   return 0; 
}
