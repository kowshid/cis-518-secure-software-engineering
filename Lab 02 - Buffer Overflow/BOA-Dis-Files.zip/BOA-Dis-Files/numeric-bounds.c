#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

int main() {

   // integer overflow problem
   int numPurchased = 42949671;
   int unitCost = 100;
   int totalCost = unitCost * numPurchased;
   printf("total cost = %d\n", totalCost);
   
   // integer underflow problem
   int p = INT_MIN;	// -2^31
   int q = p - 5;
   printf("p = %d q = %d\n", p, q);
   
   // implicit conversion from signed value to unsigned value
   int x = -100;
   unsigned int y = x;
   printf("x = %d y = %u\n", x, y);
   
   // Imagine using the value of variable x above, without bounds checking,
   // as an argument to a function like malloc() that takes an unsigned integer
   // to allocate a block of memory. As a result, malloc() attempts to allocate
   // a very large chunk (in bytes) of memory on heap.
   if (malloc(x) == NULL) {
   	printf("memory allocation failed\n");
   }
   
   // implicit conversion from unsigned value to signed value
   y = 2147483648;
   x = y;
   printf("y = %u x = %d\n", y, x);
   
   return 0;
}
