#include <stdio.h>
#include <string.h>

int main() {

   //
   char s1[] = "secure";
   char s2[20] = "software";
   char s3[10] = "";
  
   // let's print starting address of each array
   printf("Address of s1 = %p\n", s1);
   printf("Address of s2 = %p\n", s2);
   printf("Address of s3 = %p\n\n", s3);
  
   printf("Hit return to continue...");
   getchar();  // to pause the program
   
   printf("s1: \"%s\" size: %zu length: %zu\n", s1, sizeof(s1), strlen(s1));
   printf("s2: \"%s\" size: %zu length: %zu\n", s2, sizeof(s2), strlen(s2));
   printf("s3: \"%s\" size: %zu length: %zu\n", s3, sizeof(s3), strlen(s3));
   
   // using unsafe strcat()
   strcat(s2,s1);		// append s1 to s2
   strcat(s3,s1);		// append s1 to s3
   strcat(s3,s2);		// append s2 to s3
  	
   printf("Hit return to continue...");
   getchar();	// to pause the program
   
   printf("After strcat() operations...\n\n");
  	
   printf("s1: \"%s\" size: %zu length: %zu\n", s1, sizeof(s1), strlen(s1));
   printf("s2: \"%s\" size: %zu length: %zu\n", s2, sizeof(s2), strlen(s2));
   printf("s3: \"%s\" size: %zu length: %zu\n\n", s3, sizeof(s3), strlen(s3));
   //

   /*
   char s1[] = "secure";
   char s2[20] = "software";
   char s3[10] = "";
  
   // let's print starting address of each array
   printf("Address of s1 = %p\n", s1);
   printf("Address of s2 = %p\n", s2);
   printf("Address of s3 = %p\n", s3);
  
   printf("Hit return to continue...");
   getchar();  // to pause the program
   
   printf("s1: \"%s\" size: %zu length: %zu\n", s1, sizeof(s1), strlen(s1));
   printf("s2: \"%s\" size: %zu length: %zu\n", s2, sizeof(s2), strlen(s2));
   printf("s3: \"%s\" size: %zu length: %zu\n", s3, sizeof(s3), strlen(s3));
   
   // using safer strncat()
   strncat(s2,s1,sizeof(s2)-strlen(s2)-1);		// append s1 to s2
   strncat(s3,s1,sizeof(s3)-strlen(s3)-1);		// append s1 to s3
   strncat(s3,s2,sizeof(s3)-strlen(s3)-1);		// append s2 to s3
  	
   printf("Hit return to continue...");
   getchar();  // to pause the program
   
   printf("After strncat() operations...\n");
  	
   printf("s1: \"%s\" size: %zu length: %zu\n", s1, sizeof(s1), strlen(s1));
   printf("s2: \"%s\" size: %zu length: %zu\n", s2, sizeof(s2), strlen(s2));
   printf("s3: \"%s\" size: %zu length: %zu\n\n", s3, sizeof(s3), strlen(s3));
   */
}
