#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    int BUFSIZE = 15;
    char str[BUFSIZE];
    int len;
    len = snprintf(str, BUFSIZE, "%s(%d)", argv[0], argc);
    printf("%s\n", str);
    if (len >= BUFSIZE) {
        printf("length truncated (from %d)\n", len);
    }
    return EXIT_SUCCESS;
}
