// Program to check the endianness of your machine
// Program that prints the bytes of an integer value from lowest to highest address

#include <stdio.h> 

void show_mem_rep(char *start, int n);

int main() 
{ 
   int i = 0x12345678;

   // On a little endian processor, this program would print: 78 56 34 12
   // On a big endian processor, this program would print: 12 34 56 78
   show_mem_rep((char *)&i, sizeof(i));

   return 0; 
}

/* Function to show bytes in memory, from location start to start+n */
void show_mem_rep(char *start, int n) 
{ 
   int i; 
   for (i = 0; i < n; i++) {
      printf("%.2x ", start[i]);
   }
   printf("\n"); 
} 
