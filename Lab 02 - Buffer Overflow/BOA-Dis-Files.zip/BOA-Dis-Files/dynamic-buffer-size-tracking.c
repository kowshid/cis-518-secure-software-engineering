#include <stdio.h>
#include <stdlib.h>

typedef struct {
	char* ptr;
	int bufsize;
} buffer;

int main(int argc, char **argv) {
    int BUFSIZE = 15;
    int MAX_ALLOC = 50;
    buffer str;
    int len;
    if ((str.ptr = (char *) malloc(BUFSIZE)) == NULL) {
    	return EXIT_FAILURE;
    }
    str.bufsize = BUFSIZE;
    len = snprintf(str.ptr, BUFSIZE, "%s(%d)", argv[0], argc);
    if (len >= BUFSIZE) {
    	free(str.ptr);
    	if (len >= MAX_ALLOC) {
    		return EXIT_FAILURE;
    	}
    	if ((str.ptr = (char *) malloc(len + 1)) == NULL) {
    		return EXIT_FAILURE;
    	}
    	str.bufsize = len + 1;
    	len = snprintf(str.ptr, str.bufsize, "%s(%d)", argv[0], argc);
    }
    printf("%s\n", str.ptr);
    free(str.ptr);
    str.ptr = NULL;
    str.bufsize = 0;
    return EXIT_SUCCESS;
}
