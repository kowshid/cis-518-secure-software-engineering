#include <stdio.h>
#include <string.h>

int main() {

   //
   char s1[] = "computer security";
   char s2[20] = "";
   char s3[10] = "";
  
   // let's print starting address of each array
   printf("Address of s1 = %p\n", s1);
   printf("Address of s2 = %p\n", s2);
   printf("Address of s3 = %p\n", s3);

   printf("Hit return to continue...");
   getchar();	// to pause the program
   
   printf("s1: \"%s\" size: %zu length: %zu\n", s1, sizeof(s1), strlen(s1));
   printf("s2: \"%s\" size: %zu length: %zu\n", s2, sizeof(s2), strlen(s2));
   printf("s3: \"%s\" size: %zu length: %zu\n", s3, sizeof(s3), strlen(s3));
   
   // using unsafe strcpy()
   strcpy(s2,s1);	// copy s1 into s2
   strcpy(s3,s1);	// copy s1 into s3	

   printf("Hit return to continue...");
   getchar();	// to pause the program
   
   printf("After strcpy operations...\n");
  	
   printf("s1: \"%s\" size: %zu length: %zu\n", s1, sizeof(s1), strlen(s1));
   printf("s2: \"%s\" size: %zu length: %zu\n", s2, sizeof(s2), strlen(s2));
   printf("s3: \"%s\" size: %zu length: %zu\n", s3, sizeof(s3), strlen(s3));
   //
  
   /*
   // let's print starting address of each array
   char s1[] = "computer security";
   char s2[20] = "";
   char s3[10] = "";
  
   // let's print starting address of each array
   printf("Address of s1 = %p\n", s1);
   printf("Address of s2 = %p\n", s2);
   printf("Address of s3 = %p\n", s3);

   printf("Hit return to continue...");
   getchar();	// to pause the program
   
   printf("s1: \"%s\" size: %zu length: %zu\n", s1, sizeof(s1), strlen(s1));
   printf("s2: \"%s\" size: %zu length: %zu\n", s2, sizeof(s2), strlen(s2));
   printf("s3: \"%s\" size: %zu length: %zu\n", s3, sizeof(s3), strlen(s3));
   
   strncpy(s2,s1,sizeof(s2));
   //s2[sizeof(s2)-1] = '\0';		// manually null-terminate to be safe
   strncpy(s3,s1,sizeof(s3));
   //s3[sizeof(s3)-1] = '\0';
  
   printf("Hit return to continue...");
   getchar();	// to pause the program
   
   printf("After strncpy operations...\n");
  	
   printf("s1: \"%s\" size: %zu length: %zu\n", s1, sizeof(s1), strlen(s1));
   printf("s2: \"%s\" size: %zu length: %zu\n", s2, sizeof(s2), strlen(s2));
   printf("s3: \"%s\" size: %zu length: %zu\n", s3, sizeof(s3), strlen(s3));
   */
}
