#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    int BUFSIZE = 15;
    char *str;
    int len;
    if ((str = (char *) malloc(BUFSIZE)) == NULL) {
    	return EXIT_FAILURE;
    }
    len = snprintf(str, BUFSIZE, "%s(%d)", argv[0], argc);
    if (len >= BUFSIZE) {
    	free(str);
    	if ((str = (char *) malloc(len + 1)) == NULL) {
    		return EXIT_FAILURE;
    	}
    	len = snprintf(str, len + 1, "%s(%d)", argv[0], argc);
    }
    printf("%s\n", str);
    free(str);
    str = NULL;
    return EXIT_SUCCESS;
}
